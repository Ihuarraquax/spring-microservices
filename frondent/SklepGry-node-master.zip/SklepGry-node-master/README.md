# SklepGry-node



Backend - express.js, db - mongodb, mongoose wykorzystywany
Frontend - react, redux