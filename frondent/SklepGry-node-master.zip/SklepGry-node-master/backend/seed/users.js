const users = [
    {
        name: 'user',
        email: 'user@user',
        password: 'user',
        isAdmin: false
    },

    {
        name: 'admin',
        email: 'admin@admin',
        password: 'admin',
        isAdmin: true
  },
  ]
  module.exports = users;